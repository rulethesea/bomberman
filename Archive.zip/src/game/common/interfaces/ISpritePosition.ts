export interface ISpritePosition {
  x: number;
  y: number;
}
