import { IEnemy } from './IEnemy';

export interface IEnemySaved {
  x: number;
  y: number;
  enemyData: IEnemy;
}
