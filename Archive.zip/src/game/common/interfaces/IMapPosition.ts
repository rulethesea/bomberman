export interface IMapPosition {
  x: number;
  y: number;
}
