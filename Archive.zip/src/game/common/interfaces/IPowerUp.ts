export interface IPowerUp {
  id: number;
  textureKey: string;
}
