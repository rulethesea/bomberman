export enum GAME_STAGE_ENUM {
  ONE,
  TWO,
  THREE,
  FOUR,
  FIVE,
  FINAL_BONUS
}
