export enum LOCAL_STORAGE_KEYS_ENUM {
  HIGHEST_SCORE_KEY = '_bombermanJS_highest_score',
  SAVED_GAME = '_bombermanJS_saved_game'
}
