export enum ENEMY_DIRECTION_ENUM {
  UP,
  LEFT,
  RIGHT,
  DOWN
}
