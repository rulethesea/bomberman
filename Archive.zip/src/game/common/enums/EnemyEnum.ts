// Taken from: https://bomberman.fandom.com/wiki/Category:Enemies

export enum ENEMY_ENUM {
  BALLOM = 'ballom',
  ONIL = 'onil',
  MINVO = 'minvo',
  DAHL = 'dahl',
  OVAPE = 'ovape',
  PONTAN = 'pontan',
  PASS = 'pass'
}
