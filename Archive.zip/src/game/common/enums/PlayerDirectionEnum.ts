export enum PLAYER_DIRECTION_ENUM {
  UP = 'up',
  LEFT = 'left',
  RIGH = 'right',
  DOWN = 'down',
  IDLE = 'idle'
}
