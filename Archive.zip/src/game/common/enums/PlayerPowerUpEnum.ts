// Taken from: https://bomberman.fandom.com/wiki/Bomberman_(NES)/Items

export enum PLAYER_POWER_UP_ENUM {
  BOMB_UP,
  FIRE_UP,
  SPEED_UP,
  REMOTE_CONTROL,
  WALL_PASS,
  BOMB_PASS,
  FLAME_PASS
}
